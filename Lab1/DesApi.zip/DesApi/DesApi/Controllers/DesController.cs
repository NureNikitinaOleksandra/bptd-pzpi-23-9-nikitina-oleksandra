﻿using System;
using System.Linq;
using System.Text;
using DesApi.Des;
using Microsoft.AspNetCore.Mvc;

namespace DesApi.Controllers;

// Це API-контролер, і всі запити будуть йти на адресу http://localhost:.../api/des
[ApiController]
[Route("api/des")]
public sealed class DesController : ControllerBase
{
    private readonly DesCipher _cipher = new();

    // Спеціальний суворий енкодер UTF-8, який кидає виключення, якщо байти пошкоджені
    private static readonly Encoding StrictUtf8 = new UTF8Encoding(false, true);

    // Структури для прийняття та відправки JSON-даних.
    public sealed record ProcessRequest(string Text, string Key, bool IsEncrypt, bool IsHexKey);
    public sealed record ProcessResponse(string ResultHex, string ResultText, IReadOnlyList<DesCipher.RoundTrace> RoundTrace);

    // Основний метод, який приймає POST-запити від React-фронтенду.
    [HttpPost("process")]
    public ActionResult<ProcessResponse> Process([FromBody] ProcessRequest request)
    {
        if (request == null)
            return BadRequest(new { error = "Некоректний запит (відсутнє тіло JSON)." });

        try
        {
            // Перевіряємо та готуємо ключ.
            byte[] key = NormalizeKey(request.Key, request.IsHexKey);
            byte[] input;

            if (request.IsEncrypt)
            {
                if (string.IsNullOrEmpty(request.Text))
                    return BadRequest(new { error = "Введіть текст для шифрування." });

                // Перетворюємо текст на байти і додаємо доповнення PKCS#7.
                input = Encoding.UTF8.GetBytes(request.Text).AddPkcs7Padding();
            }
            else
            {
                if (string.IsNullOrWhiteSpace(request.Text))
                    return BadRequest(new { error = "Введіть шифротекст." });

                // Для дешифрування ми отримуємо HEX-рядок, тому одразу перетворюємо його на байти.
                input = BitHelper.FromHex(request.Text.Trim());
                if (input.Length == 0 || input.Length % 8 != 0)
                    return BadRequest(new { error = "Для дешифрування потрібен HEX-рядок, довжина якого кратна 16 символам (8 байтам)." });
            }

            var processed = _cipher.Transform(input, key, request.IsEncrypt);
            string resultHex = BitHelper.ToHex(processed.Data);

            // Беремо трасування лише для перших 16 раундів.
            var trace = processed.Trace.Take(16).ToArray();
            string resultText = "";

            if (request.IsEncrypt)
            {
                resultText = resultHex;
            }
            else
            {
                // При дешифруванні знімаємо PKCS#7 доповнення.
                byte[] unpadded = processed.Data.RemovePkcs7Padding();
                // Суворе декодування: викине DecoderFallbackException, якщо ввели неправильний ключ.
                resultText = StrictUtf8.GetString(unpadded);
            }

            return Ok(new ProcessResponse(resultHex, resultText, trace));
        }
        catch (DecoderFallbackException)
        {
            return BadRequest(new { error = "Помилка дешифрування: результат не є валідним UTF-8 текстом (можливо, введено неправильний ключ або пошкоджено шифротекст)." });
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new { error = ex.Message });
        }
        catch (Exception)
        {
            return StatusCode(500, new { error = "Сталася внутрішня помилка обробки. Перевірте коректність даних та ключа." });
        }
    }

    // Допоміжний метод для підготовки ключа залежно від того, як його ввів користувач.
    private static byte[] NormalizeKey(string keyText, bool isHexKey)
    {
        if (isHexKey)
        {
            keyText = keyText.Replace(" ", "");
            if (string.IsNullOrWhiteSpace(keyText) || keyText.Length != 16)
                throw new ArgumentException("HEX-ключ має містити рівно 16 символів.");
            return BitHelper.FromHex(keyText);
        }

        if (string.IsNullOrEmpty(keyText))
            throw new ArgumentException("Введіть ключ.");

        byte[] bytes = Encoding.UTF8.GetBytes(keyText);

        if (bytes.Length != 8)
        {
            string charCount = keyText.Length.ToString();
            string byteCount = bytes.Length.ToString();
            throw new ArgumentException($"Текстовий ключ повинен займати рівно 8 байтів UTF-8. Ви ввели {charCount} символів, які займають {byteCount} байт(ів) у пам'яті.");
        }

        return bytes;
    }
}