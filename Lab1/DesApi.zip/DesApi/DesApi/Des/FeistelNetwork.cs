﻿using System.Collections;

namespace DesApi.Des;

// Цей клас реалізує функцію Фейстеля, 
// виконується 16 разів, тобто в кожному раунді.
public sealed class FeistelNetwork
{
    // Головний метод функції Фейстеля. Приймає праву половину даних (32 біти) 
    // та ключ поточного раунду (48 бітів). Повертає оброблені 32 біти.
    public BitArray RoundFunction(BitArray rightHalf, BitArray roundKey)
    {
        if (rightHalf.Length != 32 || roundKey.Length != 48)
            throw new ArgumentException("Очікуються R = 32 біти та ключ = 48 бітів.");

        // 1. Розширення (32 біти -> 48 бітів).
        var expanded = Expand(rightHalf);

        // 2. Додавання ключа (XOR розширеного блоку з раундовим підключем).
        var mixed = BitHelper.Xor(expanded, roundKey);

        // 3. Підстановки в S-блоках (48 бітів стискаються назад у 32 біти).
        var substituted = ApplySBoxes(mixed);

        // 4. Фінальне перемішування результату.
        return Permute(substituted);
    }

    // Розширює 32 біти до 48 за допомогою таблиці E (Expansion).
    // Деякі біти дублюються, щоб зрівняти розмір блоку з розміром ключа.
    private BitArray Expand(BitArray input)
    {
        if (input.Length != 32)
            throw new ArgumentException("E-розширення приймає 32 біти.");

        return BitHelper.Permute(input, DesTables.E);
    }

    // Пропускання даних через 8 нелінійних S-блоків.
    private BitArray ApplySBoxes(BitArray input)
    {
        if (input.Length != 48)
            throw new ArgumentException("S-блоки приймають 48 бітів.");

        var output = new BitArray(32);

        // Вхідні 48 бітів розбиваються на 8 груп по 6 бітів.
        for (int box = 0; box < 8; box++)
        {
            int offset = box * 6; // Вказівник на початок поточної 6-бітної групи.

            // Рядок утворюють перший і останній біти.
            int row = (input[offset] ? 2 : 0)
                    | (input[offset + 5] ? 1 : 0);

            // Середні чотири біти визначають стовпець.
            int column = 0;
            for (int j = 1; j <= 4; j++)
                column = (column << 1) | (input[offset + j] ? 1 : 0);

            // Отримуємо десяткове число від 0 до 15 з тривимірної таблиці S_BOX.
            int value = DesTables.S_BOX[box][row][column];

            // Кожен S-блок повертає 4 біти від старшого до молодшого.
            for (int bit = 0; bit < 4; bit++)
                output[box * 4 + bit] =
                    (value & (1 << (3 - bit))) != 0;
        }

        return output;
    }

    // Пряма перестановка за таблицею P після виходу з S-блоків.
    private BitArray Permute(BitArray input) =>
        BitHelper.Permute(input, DesTables.P);
}

