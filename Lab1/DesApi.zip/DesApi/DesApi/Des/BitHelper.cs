﻿using System;
using System.Collections;
using System.Linq;

namespace DesApi.Des;

// Цей клас містить усі низькорівневі операції для роботи з бітами.
public static class BitHelper
{
    // Перетворює масив байтів у масив бітів.
    public static BitArray ToBits(byte[] bytes)
    {
        if (bytes == null) throw new ArgumentNullException(nameof(bytes));
        var bits = new BitArray(bytes.Length * 8);
        for (int i = 0; i < bytes.Length; i++)
            for (int j = 0; j < 8; j++)
                // Витягуємо кожен біт з байта за допомогою побітового зсуву та маски.
                bits[i * 8 + j] = (bytes[i] & (1 << (7 - j))) != 0;
        return bits;
    }

    // Збирає біти назад у байти.
    public static byte[] ToBytes(BitArray bits)
    {
        if (bits == null) throw new ArgumentNullException(nameof(bits));
        if (bits.Length % 8 != 0)
            throw new ArgumentException("Кількість бітів має бути кратною 8.");
        var bytes = new byte[bits.Length / 8];
        for (int i = 0; i < bits.Length; i++)
            if (bits[i])
                bytes[i / 8] |= (byte)(1 << (7 - i % 8));
        return bytes;
    }

    // Універсальний метод для всіх перестановок (IP, PC-1, E, P тощо).
    // Приймає вхідний масив бітів і таблицю, за якою їх треба перемішати.
    public static BitArray Permute(BitArray input, int[] table)
    {
        if (input == null) throw new ArgumentNullException(nameof(input));
        if (table == null) throw new ArgumentNullException(nameof(table));

        var output = new BitArray(table.Length);
        for (int i = 0; i < table.Length; i++)
        {
            // У таблицях DES індексація починається з 1, а в C# з 0, тому віднімаємо 1.
            int sourceIndex = table[i] - 1;
            if (sourceIndex < 0 || sourceIndex >= input.Length)
                throw new ArgumentException("Некоректна таблиця перестановки.");
            output[i] = input[sourceIndex];
        }
        return output;
    }

    // Побітове "Виключне АБО" (XOR) для двох масивів однакової довжини
    public static BitArray Xor(BitArray a, BitArray b)
    {
        if (a == null) throw new ArgumentNullException(nameof(a));
        if (b == null) throw new ArgumentNullException(nameof(b));
        if (a.Length != b.Length)
            throw new ArgumentException("Довжини бітових масивів не збігаються.");

        var result = (BitArray)a.Clone();
        result.Xor(b); // Вбудований метод BitArray.
        return result;
    }

    // Розділяє масив бітів навпіл(наприклад, 64 біти на L0 та R0 по 32 біти).
    public static (BitArray Left, BitArray Right) Split(BitArray bits)
    {
        if (bits == null) throw new ArgumentNullException(nameof(bits));
        if (bits.Length % 2 != 0)
            throw new ArgumentException("Масив повинен мати парну довжину.");

        int half = bits.Length / 2;
        var left = new BitArray(half);
        var right = new BitArray(half);
        for (int i = 0; i < half; i++)
        {
            left[i] = bits[i];
            right[i] = bits[i + half];
        }
        return (left, right);
    }

    // Склеює два масиви бітів у один.
    public static BitArray Concat(BitArray left, BitArray right)
    {
        if (left == null) throw new ArgumentNullException(nameof(left));
        if (right == null) throw new ArgumentNullException(nameof(right));

        var result = new BitArray(left.Length + right.Length);
        for (int i = 0; i < left.Length; i++)
            result[i] = left[i];
        for (int i = 0; i < right.Length; i++)
            result[left.Length + i] = right[i];
        return result;
    }

    // Циклічний зсув вліво. Використовується при генерації раундових ключів.
    public static BitArray RotateLeft(BitArray bits, int count)
    {
        if (bits == null) throw new ArgumentNullException(nameof(bits));
        var result = new BitArray(bits.Length);
        for (int i = 0; i < bits.Length; i++)
            result[i] = bits[(i + count) % bits.Length];
        return result;
    }

    // Допоміжні методи для роботи з HEX-рядками в інтерфейсі
    public static string ToHex(byte[] bytes)
    {
        if (bytes == null) throw new ArgumentNullException(nameof(bytes));
        return Convert.ToHexString(bytes);
    }

    public static byte[] FromHex(string hex)
    {
        if (string.IsNullOrWhiteSpace(hex)) throw new ArgumentException("HEX-рядок не може бути порожнім.");

        // Видаляємо пробіли, якщо користувач їх ввів
        hex = hex.Replace(" ", "");

        // Перевіряємо, чи можна взагалі розбити рядок на байти
        if (hex.Length % 2 != 0)
            throw new ArgumentException("Для дешифрування потрібен HEX-рядок, довжина якого кратна 16 символам (8 байтам).");

        try
        {
            return Convert.FromHexString(hex);
        }
        catch (FormatException)
        {
            throw new ArgumentException("Результат має бути коректним HEX-рядком (дозволені лише символи 0-9 та A-F).");
        }
    }
}

// Розширення для масивів байтів, щоб зручно додавати та знімати доповнення PKCS#7.
public static class ByteArrayExtensions
{
    // Доповнює дані до кратності 8 байтам.
    public static byte[] AddPkcs7Padding(this byte[] input)
    {
        if (input == null) throw new ArgumentNullException(nameof(input));

        int padLength = 8 - (input.Length % 8);
        var padded = new byte[input.Length + padLength];
        Array.Copy(input, padded, input.Length);

        // Записуємо значення, яке дорівнює кількості доданих байтів.
        for (int i = input.Length; i < padded.Length; i++)
        {
            padded[i] = (byte)padLength;
        }
        return padded;
    }

    // Зняття доповнення після розшифрування
    public static byte[] RemovePkcs7Padding(this byte[] bytes)
    {
        if (bytes == null || bytes.Length == 0 || bytes.Length % 8 != 0)
            throw new ArgumentException("Некоректна довжина даних для зняття PKCS#7.");

        int padLength = bytes[bytes.Length - 1];

        if (padLength < 1 || padLength > 8)
            throw new ArgumentException("Некоректне значення доповнення PKCS#7. Дані пошкоджені або використано неправильний ключ.");

        for (int i = bytes.Length - padLength; i < bytes.Length; i++)
        {
            if (bytes[i] != padLength)
                throw new ArgumentException("Помилка цілісності PKCS#7 доповнення. Розшифровані байти не відповідають стандарту.");
        }

        return bytes.Take(bytes.Length - padLength).ToArray();
    }
}