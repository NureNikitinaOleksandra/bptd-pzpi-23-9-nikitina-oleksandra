﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace DesApi.Des;

// Головний клас-оркестратор (Фасад). Він не виконує математику сам, 
// а керує розкладом ключів, мережею Фейстеля та розбиттям тексту на блоки.
public sealed class DesCipher
{
    private readonly KeySchedule _keySchedule = new();
    private readonly FeistelNetwork _feistel = new();

    // Структури для збереження проміжних результатів (щоб вивести їх у React).
    public sealed record RoundTrace(int Round, string LeftHex, string RightHex, double Entropy);
    public sealed record BlockResult(byte[] Data, IReadOnlyList<RoundTrace> Trace);

    // Основний метод для обробки повного тексту будь-якої довжини.
    public BlockResult Transform(byte[] data, byte[] key, bool isEncrypting)
    {
        if (data == null) throw new ArgumentNullException(nameof(data));
        if (key == null) throw new ArgumentNullException(nameof(key));
        if (key.Length != 8)
            throw new ArgumentException("Ключ повинен мати 8 байтів.");
        if (data.Length == 0 || data.Length % 8 != 0)
            throw new ArgumentException("Дані повинні містити блоки по 8 байтів.");

        // Генеруємо 16 раундових ключів.
        var keys = _keySchedule.GenerateKeys(key);

        // Ключі застосовуються у зворотному порядку(від 16 - го до 1 - го).
        if (!isEncrypting)
            keys.Reverse();

        var output = new byte[data.Length];
        var trace = new List<RoundTrace>();

        // Розбиваємо весь текст на шматки по 8 байт (64 біти).
        for (int offset = 0; offset < data.Length; offset += 8)
        {
            var block = new byte[8];
            Array.Copy(data, offset, block, 0, 8);

            var processed = ProcessBlock(block, keys);

            // Збираємо оброблені блоки назад у єдиний масив.
            Array.Copy(processed.Data, 0, output, offset, 8);
            trace.AddRange(processed.Trace);
        }
        return new BlockResult(output, trace);
    }

    // Внутрішній метод, який проганяє рівно 64 біти через 16 раундів.
    private BlockResult ProcessBlock(byte[] block, List<BitArray> keys)
    {
        // 1. Початкова перестановка.
        var bits = BitHelper.Permute(BitHelper.ToBits(block), DesTables.IP);

        // 2. Розбиваємо 64 біти на дві половини L0 та R0 по 32 біти.
        var (left, right) = BitHelper.Split(bits);

        var trace = new List<RoundTrace>(16);
        var entropy = new EntropyCalculator();

        // 3. Мережа Фейстеля (16 ітерацій).
        for (int round = 0; round < 16; round++)
        {
            var nextLeft = right; // Права частина стає лівою.

            // Ліва частина XOR-иться з результатом функції Фейстеля від правої частини та ключа.
            var nextRight = BitHelper.Xor(left, _feistel.RoundFunction(right, keys[round]));

            left = nextLeft;
            right = nextRight;

            // Збір аналітики для інтерфейсу.
            var state = BitHelper.ToBytes(BitHelper.Concat(left, right));
            double h = entropy.CalculateAndStoreEntropy(state);
            trace.Add(new RoundTrace(
                round + 1,
                BitHelper.ToHex(BitHelper.ToBytes(left)),
                BitHelper.ToHex(BitHelper.ToBytes(right)),
                h));
        }

        // 4. Кінцева перестановка IP⁻¹.
        var outputBits = BitHelper.Permute(BitHelper.Concat(right, left), DesTables.IP_INV);

        return new BlockResult(BitHelper.ToBytes(outputBits), trace);
    }
}