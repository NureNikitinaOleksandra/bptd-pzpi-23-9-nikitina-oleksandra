﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace DesApi.Des;

// Відповідає за підготовку ключів.
// З одного початкового 64-бітного ключа він генерує шістнадцять 48-бітних підключів для кожного раунду.
public sealed class KeySchedule
{
    public List<BitArray> GenerateKeys(byte[] key)
    {
        // 1. Базова перевірка довжини. DES працює тільки з 8-байтовими ключами.
        if (key.Length != 8)
            throw new ArgumentException("Ключ DES повинен містити рівно 8 байтів.");

        // 2. Валідація на слабкі ключі. 
        // Перетворюємо ключ у HEX і шукаємо його в нашому словнику слабких ключів.
        string keyHex = BitHelper.ToHex(key);
        if (DesTables.WeakKeys.Contains(keyHex, StringComparer.OrdinalIgnoreCase))
            throw new ArgumentException("Використано слабкий ключ DES. Оберіть інший ключ.");

        // 3. Первинна перестановка.
        // Тут 64-бітний ключ перетворюється на 56-бітний. 
        // Кожен 8-й біт (біт парності) просто відкидається.
        var effectiveKey = BitHelper.Permute(BitHelper.ToBits(key), DesTables.PC_1);

        // 4. Розбиваємо 56-бітний ключ на дві рівні половини по 28 бітів (C та D).
        var (c, d) = BitHelper.Split(effectiveKey);

        // Створюємо список, де будемо зберігати готові ключі для 16 раундів.
        var keys = new List<BitArray>(16);

        // 5. Цикл генерації раундових ключів.
        for (int round = 0; round < 16; round++)
        {
            // Дивимося в таблицю, на скільки бітів треба зсунути половинки в поточному раунді (на 1 або 2).
            int shifts = DesTables.ShiftSchedule[round];

            // Виконуємо циклічний зсув вліво для обох половинок.
            c = BitHelper.RotateLeft(c, shifts);
            d = BitHelper.RotateLeft(d, shifts);

            // Склеюємо зсунуті половинки назад у 56 бітів.
            var combined = BitHelper.Concat(c, d);

            // 6. Фінальна перестановка раунду.
            // Вона обирає 48 бітів із поточних 56. Це і є готовий раундовий ключ.
            keys.Add(BitHelper.Permute(combined, DesTables.PC_2));
        }

        // Повертаємо масив із 16 готових підключів.
        return keys;
    }
}