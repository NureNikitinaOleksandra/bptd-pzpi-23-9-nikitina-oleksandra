﻿using System.Collections;

namespace DesApi.Des;

// Цей клас відповідає за аналітику шифру. Він обчислює бітову ентропію Шеннона.
public sealed class EntropyCalculator
{
    // Список для збереження історії ентропії.
    public List<double> RoundEntropies { get; } = new();

    // Головний метод обчислення. Приймає поточний стан блоку (L + R) = 8 байтів.
    public double CalculateAndStoreEntropy(byte[] currentData)
    {
        // Перевіряємо, чи точно передали 64 біти (8 байтів).
        if (currentData.Length != 8)
            throw new ArgumentException("Потрібен блок розміром 64 біти.");

        // Конвертуємо байти в біти.
        BitArray bits = BitHelper.ToBits(currentData);

        // Рахуємо кількість одиниць у блоці.
        int ones = 0;
        for (int i = 0; i < bits.Length; i++)
            if (bits[i])
                ones++;

        // Обчислюємо ймовірність появи одиниці (p1) та нуля (p0).
        double p1 = ones / (double)bits.Length;
        double p0 = 1.0 - p1;

        double entropy = 0;

        // Застосовуємо формулу Шеннона.
        if (p0 > 0)
            entropy -= p0 * Math.Log2(p0);

        if (p1 > 0)
            entropy -= p1 * Math.Log2(p1);

        // Зберігаємо поточне значення в історію та повертаємо його.
        RoundEntropies.Add(entropy);
        return entropy;
    }
}
