﻿namespace RsaServer.Models.DTOs
{
    public class PublicKeyDto
    {
        // Відкритий ключ Kb (або E)
        public string E { get; set; } = string.Empty;
        // Модуль N
        public string N { get; set; } = string.Empty;
    }
}