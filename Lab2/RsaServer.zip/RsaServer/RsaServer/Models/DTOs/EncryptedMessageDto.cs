﻿using System.Collections.Generic;

namespace RsaServer.Models.DTOs
{
    // Клас для одного зашифрованого блоку
    public class EncryptedBlockDto
    {
        // Зашифроване велике число у вигляді рядка
        public string Value { get; set; } = string.Empty;

        // Початкова довжина блоку в байтах (щоб не втратити нульові байти при розшифруванні)
        public int ByteLength { get; set; }
    }

    // Запит, який прийде від React-клієнта з формою
    public class LoginRequestDto
    {
        public List<EncryptedBlockDto> UsernameBlocks { get; set; } = new List<EncryptedBlockDto>();
        public List<EncryptedBlockDto> PasswordBlocks { get; set; } = new List<EncryptedBlockDto>();

        public string ClientE { get; set; } = string.Empty;
        public string ClientN { get; set; } = string.Empty;
    }
}