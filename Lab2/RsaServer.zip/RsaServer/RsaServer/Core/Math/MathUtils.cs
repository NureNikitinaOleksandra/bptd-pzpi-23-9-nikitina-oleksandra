﻿using System;
using System.Numerics;

namespace RsaServer.Core.Math
{
    public static class MathUtils
    {
        // Класичний алгоритм Евкліда для знаходження Найбільшого Спільного Дільника (НСД).
        // Потрібен для перевірки, чи є відкритий ключ E взаємно простим із функцією Ейлера Phi(N).
        public static BigInteger GreatestCommonDivisor(BigInteger a, BigInteger b)
        {
            a = BigInteger.Abs(a);
            b = BigInteger.Abs(b);
            while (b != 0)
            {
                BigInteger temp = b;
                b = a % b; // Залишок від ділення
                a = temp;
            }
            return a;
        }

        // Розширений алгоритм Евкліда. Шукає таке число D (секретний ключ), 
        // для якого виконується умова: (D * E) mod Phi(N) = 1.
        public static BigInteger ExtendedEuclidean(BigInteger e, BigInteger phi)
        {
            if (phi <= 1)
                throw new ArgumentOutOfRangeException(nameof(phi), "Значення функції Ейлера має бути більшим за 1.");
            if (e <= 0)
                throw new ArgumentOutOfRangeException(nameof(e), "Відкрита експонента має бути додатною.");

            // t - майбутній секретний ключ D
            BigInteger t = 0, newt = 1;
            BigInteger r = phi, newr = e;

            while (newr != 0)
            {
                BigInteger quotient = r / newr; // Цілочисельне ділення

                BigInteger tempT = t - quotient * newt;
                t = newt;
                newt = tempT;

                BigInteger tempR = r - quotient * newr;
                r = newr;
                newr = tempR;
            }

            // Якщо остаточний залишок > 1, числа не взаємно прості (алгоритм RSA не спрацює)
            if (r > 1)
                throw new Exception("E та функція Ейлера не є взаємно простими!");

            // C# може повертати від'ємні залишки, тому робимо універсальну нормалізацію.
            // Вона гарантує, що секретний ключ D буде додатним числом у межах від 0 до Phi.
            t = ((t % phi) + phi) % phi;
            return t;
        }
    }
}