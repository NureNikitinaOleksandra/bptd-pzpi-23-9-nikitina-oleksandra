﻿using System;
using System.Numerics;
using System.Security.Cryptography;

namespace RsaServer.Core.Math
{
    public class PrimeGenerator
    {
        // Генерує просте число заданої довжини (за замовчуванням 1024 біти)
        public BigInteger GeneratePrime(int bits = 1024)
        {
            if (bits < 16 || bits % 8 != 0)
                throw new ArgumentOutOfRangeException(nameof(bits), "Розмір числа повинен бути додатним кратним 8.");

            int bytes = bits / 8;
            byte[] data = new byte[bytes];
            BigInteger candidate;

            while (true)
            {
                // Використовуємо криптографічно стійкий генератор випадкових чисел
                RandomNumberGenerator.Fill(data);

                // Встановлюємо молодший біт в 1 (операція OR). Гарантує, що число буде НЕПАРНИМ (парні не бувають простими).
                data[0] |= 1;
                // Встановлюємо найстарший біт в 1. Гарантує, що число матиме рівно задану кількість бітів.
                data[bytes - 1] |= 0x80;

                // Додаємо нульовий байт в кінець, щоб C# інтерпретував число як ДОДАТНЕ (Unsigned)
                byte[] unsignedData = new byte[bytes + 1];
                Array.Copy(data, unsignedData, bytes);
                candidate = new BigInteger(unsignedData);

                // Перевіряємо згенероване число тестом Міллера-Рабіна (10 раундів достатньо для 99.999% точності)
                if (IsProbablyPrime(candidate, 10))
                {
                    return candidate;
                }
            }
        }

        // Тест Міллера-Рабіна на простоту. Заснований на малій теоремі Ферма.
        private bool IsProbablyPrime(BigInteger n, int k)
        {
            if (n <= 1 || n == 4) return false;
            if (n <= 3) return true;

            // Розкладаємо n - 1 у вигляді d * 2^r
            BigInteger d = n - 1;
            int r = 0;
            while (d.IsEven) // Поки d ділиться на 2
            {
                d /= 2;
                r++;
            }

            for (int i = 0; i < k; i++)
            {
                // Беремо випадкову основу 'a'
                BigInteger a = RandomInRange(2, n - 2);

                // Обчислюємо x = a^d mod n
                BigInteger x = BigInteger.ModPow(a, d, n);

                if (x == 1 || x == n - 1)
                    continue;

                bool isComposite = true;
                // Послідовне піднесення до квадрата
                for (int j = 1; j < r; j++)
                {
                    x = BigInteger.ModPow(x, 2, n);
                    if (x == n - 1)
                    {
                        isComposite = false; // Знайшли ймовірно просте
                        break;
                    }
                }

                if (isComposite) return false; // Якщо жодна умова не виконується - число точно складене
            }
            return true;
        }

        // Допоміжний метод: генерує випадкове число у вказаному діапазоні (метод відхилення/rejection sampling)
        private static BigInteger RandomInRange(BigInteger min, BigInteger max)
        {
            BigInteger range = max - min + 1;
            int byteCount = (int)((range.GetBitLength() + 7) / 8); // Рахуємо необхідну кількість байтів
            byte[] randomBytes = new byte[byteCount];

            while (true)
            {
                RandomNumberGenerator.Fill(randomBytes);
                // Додаємо нульовий байт для знаку
                byte[] unsignedBytes = new byte[byteCount + 1];
                Array.Copy(randomBytes, unsignedBytes, byteCount);

                BigInteger candidate = new BigInteger(unsignedBytes);
                if (candidate < range) // Якщо згенероване число влазить у діапазон — беремо його
                {
                    return min + candidate;
                }
            }
        }
    }
}