﻿using System;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using RsaServer.Models.DTOs;
using RsaServer.Services;

namespace RsaServer.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IRsaCryptographyService _rsaService;
        private readonly ILogger<AuthController> _logger;
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _environment;

        // Впровадження залежностей (Dependency Injection)
        public AuthController(
            IRsaCryptographyService rsaService,
            ILogger<AuthController> logger,
            IConfiguration configuration,
            IWebHostEnvironment environment)
        {
            _rsaService = rsaService;
            _logger = logger;
            _configuration = configuration;
            _environment = environment;
        }

        // GET-запит. Клієнт звертається сюди при завантаженні сторінки, щоб забрати Відкритий Ключ.
        [HttpGet("public-key")]
        public ActionResult<PublicKeyDto> GetPublicKey()
        {
            return Ok(_rsaService.GetPublicKey());
        }

        // POST-запит. Клієнт відправляє сюди зашифровані блоки паролю та логіну.
        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginRequestDto request)
        {
            if (request is null || request.UsernameBlocks is null || request.PasswordBlocks is null)
            {
                return BadRequest(new { message = "Некоректна структура запиту." });
            }

            try
            {
                // Демонстраційний вивід ЗАШИФРОВАНИХ даних (у середовищі Development)
                if (_environment.IsDevelopment() && _configuration.GetValue<bool>("Lab:ShowDecryptedCredentials"))
                {
                    Console.WriteLine("\n================ [Лабораторний режим] Отримано POST-запит ================");

                    Console.WriteLine("--- 1. ЗАШИФРОВАНІ БЛОКИ ЛОГІНУ (Encrypted Username): ---");
                    for (int i = 0; i < request.UsernameBlocks.Count; i++)
                    {
                        var block = request.UsernameBlocks[i];
                        Console.WriteLine($"  Блок [{i + 1}] (ByteLength = {block.ByteLength}): {block.Value}");
                    }

                    Console.WriteLine("\n--- 2. ЗАШИФРОВАНІ БЛОКИ ПАРОЛЮ (Encrypted Password): ---");
                    for (int i = 0; i < request.PasswordBlocks.Count; i++)
                    {
                        var block = request.PasswordBlocks[i];
                        Console.WriteLine($"  Блок [{i + 1}] (ByteLength = {block.ByteLength}): {block.Value}");
                    }
                }

                // Виконуємо розшифрування за допомогою секретного ключа (D, N)
                string decryptedUsername = _rsaService.Decrypt(request.UsernameBlocks);
                string decryptedPassword = _rsaService.Decrypt(request.PasswordBlocks);

                // Демонстраційний вивід РОЗШИФРОВАНИХ даних
                if (_environment.IsDevelopment() && _configuration.GetValue<bool>("Lab:ShowDecryptedCredentials"))
                {
                    Console.WriteLine("\n--- 3.результат РОЗШИФРУВАННЯ НА СЕРВЕРІ: ---");
                    Console.WriteLine($"Розшифрований логін:  {decryptedUsername}");
                    Console.WriteLine($"Розшифрований пароль: {decryptedPassword}");
                    Console.WriteLine("===================================================\n");
                }

                // Формуємо текст, який хочемо відправити клієнту (у форматі JSON-рядка)
                string responseText = System.Text.Json.JsonSerializer.Serialize(new
                {
                    message = "Дані успішно розшифровані сервером!",
                    username = decryptedUsername
                });

                // Шифруємо цей текст відкритим ключем клієнта
                var encryptedResponseBlocks = _rsaService.Encrypt(responseText, request.ClientE, request.ClientN);

                if (_environment.IsDevelopment() && _configuration.GetValue<bool>("Lab:ShowDecryptedCredentials"))
                {
                    Console.WriteLine("--- [Двостороннє шифрування] ---");
                    Console.WriteLine($"Отримано відкритий ключ клієнта: E={request.ClientE}, N={request.ClientN}");
                    Console.WriteLine($"Сформовано JSON-відповідь: {responseText}");
                    Console.WriteLine($"Відповідь зашифровано відкритим ключем клієнта. Кількість блоків: {encryptedResponseBlocks.Count}");

                    // Виводимо самі зашифровані блоки
                    for (int i = 0; i < encryptedResponseBlocks.Count; i++)
                    {
                        Console.WriteLine($"  Блок [{i + 1}] (ByteLength = {encryptedResponseBlocks[i].ByteLength}): {encryptedResponseBlocks[i].Value}");
                    }
                    Console.WriteLine("===================================================\n");
                }

                // Повертаємо зашифровані блоки замість відкритого тексту
                return Ok(encryptedResponseBlocks);
            }
            catch (FormatException ex)
            {
                // Обробляємо помилки формату (наприклад, якщо хтось втрутився в шифротекст)
                _logger.LogWarning("Отримано некоректні зашифровані дані: {Error}", ex.Message);
                return BadRequest(new { message = "Помилка обробки зашифрованих даних (неправильний формат RSA-блоків)." });
            }
        }
    }
}