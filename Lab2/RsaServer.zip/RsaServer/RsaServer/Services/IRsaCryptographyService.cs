﻿using System.Collections.Generic;
using RsaServer.Models.DTOs;

namespace RsaServer.Services
{
    public interface IRsaCryptographyService
    {
        PublicKeyDto GetPublicKey();
        string Decrypt(List<EncryptedBlockDto> blocks);
        List<EncryptedBlockDto> Encrypt(string text, string clientEStr, string clientNStr);
    }
}