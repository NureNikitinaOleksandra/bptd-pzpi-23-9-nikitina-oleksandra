﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Numerics;
using System.Text;
using Microsoft.Extensions.Configuration;
using RsaServer.Core.Math;
using RsaServer.Models.DTOs;

namespace RsaServer.Services
{
    public class RsaCryptographyService : IRsaCryptographyService
    {
        private BigInteger _n; // Модуль алгоритму
        private BigInteger _e; // Відкрита експонента (Public Key)
        private BigInteger _d; // Секретна експонента (Private Key)

        // Суворий декодер UTF-8. Якщо дані пошкодяться під час передачі, він викине помилку замість "кракозябр".
        private static readonly UTF8Encoding StrictUtf8 = new UTF8Encoding(false, true);

        public RsaCryptographyService(IConfiguration configuration)
        {
            // Беремо розмір простих чисел з конфігурації. Якщо немає — використовуємо 1024.
            int primeBits = configuration.GetValue<int>("Rsa:PrimeBits", 1024);
            GenerateKeys(primeBits);
        }

        // Основна функція генерації ключів за алгоритмом RSA
        private void GenerateKeys(int primeBits)
        {
            var primeGen = new PrimeGenerator();

            // 1. Обираємо два великих простих числа P і Q
            BigInteger p = primeGen.GeneratePrime(primeBits);
            BigInteger q;
            // Гарантуємо, що вони не однакові
            do { q = primeGen.GeneratePrime(primeBits); } while (p == q);

            // 2. Обчислюємо модуль N
            _n = p * q;
            // 3. Обчислюємо значення функції Ейлера
            BigInteger phi = (p - 1) * (q - 1);
            // 4. Обираємо E (відкриту експоненту).
            _e = 65537;

            // Перевіряємо взаємну простоту. Якщо ні — генеруємо нові P та Q.
            while (MathUtils.GreatestCommonDivisor(_e, phi) != 1)
            {
                p = primeGen.GeneratePrime(primeBits);
                do { q = primeGen.GeneratePrime(primeBits); } while (p == q);
                _n = p * q;
                phi = (p - 1) * (q - 1);
            }

            // 5. Знаходимо секретний ключ D за допомогою розширеного алгоритму Евкліда
            _d = MathUtils.ExtendedEuclidean(_e, phi);
        }

        public PublicKeyDto GetPublicKey()
        {
            return new PublicKeyDto
            {
                // InvariantCulture гарантує відсутність пробілів чи ком у числах незалежно від мови Windows
                E = _e.ToString(CultureInfo.InvariantCulture),
                N = _n.ToString(CultureInfo.InvariantCulture)
            };
        }

        // Метод розшифрування повідомлення (M = C^D mod N)
        public string Decrypt(List<EncryptedBlockDto> blocks)
        {
            if (blocks == null || blocks.Count == 0)
                throw new FormatException("Отримано порожній список зашифрованих блоків.");

            var decryptedBytes = new List<byte>();

            // Рахуємо максимальну довжину блоку в байтах, яку здатне зашифрувати число N
            int maxBlockLength = (int)((_n.GetBitLength() - 1) / 8);

            foreach (var block in blocks)
            {
                if (block is null)
                    throw new FormatException("Отримано порожній блок (null).");

                if (block.ByteLength < 1 || block.ByteLength > maxBlockLength)
                    throw new FormatException("Некоректна довжина зашифрованого блока.");

                // Парсимо шифротекст C
                if (string.IsNullOrEmpty(block.Value) ||
                    !BigInteger.TryParse(block.Value, NumberStyles.None, CultureInfo.InvariantCulture, out BigInteger c))
                {
                    throw new FormatException("Некоректний формат шифротексту.");
                }

                // Головне правило RSA: числове представлення блоку має бути меншим за N
                if (c < 0 || c >= _n)
                    throw new FormatException("Шифротекст виходить за допустимий діапазон (C < N).");

                // Виконуємо безпосереднє РОЗШИФРУВАННЯ: M = C^D mod N (вбудоване модульне піднесення до степеня)
                BigInteger m = BigInteger.ModPow(c, _d, _n);

                // Переводимо розшифроване число назад у байти
                byte[] mBytes = m.ToByteArray(isUnsigned: true, isBigEndian: true);

                if (mBytes.Length > block.ByteLength)
                    throw new FormatException("Розмір відновленого блока перевищує очікуваний.");

                // Padding (Доповнення): відновлюємо початкові нульові байти, які "з'їло" числове представлення
                byte[] paddedBytes = new byte[block.ByteLength];
                int offset = block.ByteLength - mBytes.Length;

                // Копіюємо байти числа зі зсувом (offset), щоб нулі залишились зліва
                Array.Copy(mBytes, 0, paddedBytes, offset, mBytes.Length);
                decryptedBytes.AddRange(paddedBytes);
            }

            try
            {
                // Переводимо фінальний масив байтів назад у рядок UTF-8
                return StrictUtf8.GetString(decryptedBytes.ToArray());
            }
            catch (DecoderFallbackException ex)
            {
                throw new FormatException("Розшифровані байти не є коректним UTF-8 текстом.", ex);
            }
        }

        // Метод шифрування
        public List<EncryptedBlockDto> Encrypt(string text, string clientEStr, string clientNStr)
        {
            if (string.IsNullOrEmpty(text))
                throw new ArgumentException("Текст для шифрування не може бути порожнім.");

            // Безпечний парсинг ключів клієнта
            if (string.IsNullOrWhiteSpace(clientEStr) ||
                string.IsNullOrWhiteSpace(clientNStr) ||
                !BigInteger.TryParse(clientEStr, NumberStyles.None, CultureInfo.InvariantCulture, out BigInteger clientE) ||
                !BigInteger.TryParse(clientNStr, NumberStyles.None, CultureInfo.InvariantCulture, out BigInteger clientN))
            {
                throw new FormatException("Некоректний відкритий ключ клієнта.");
            }

            // Перевірка діапазонів
            if (clientE != 65537 || clientN <= 1 || clientE >= clientN)
            {
                throw new FormatException("Недопустимі параметри відкритого ключа клієнта.");
            }

            // Перетворюємо текст відповіді у байти
            byte[] textBytes = StrictUtf8.GetBytes(text);

            // Рахуємо максимальний розмір блоку під модуль клієнта
            int maxBlockLength = (int)((clientN.GetBitLength() - 1) / 8);
            if (maxBlockLength <= 0)
                throw new FormatException("Модуль клієнта занадто малий для шифрування.");

            var encryptedBlocks = new List<EncryptedBlockDto>();

            // Розбиваємо на блоки і шифруємо
            for (int i = 0; i < textBytes.Length; i += maxBlockLength)
            {
                int currentBlockSize = Math.Min(maxBlockLength, textBytes.Length - i);
                byte[] chunk = new byte[currentBlockSize];
                Array.Copy(textBytes, i, chunk, 0, currentBlockSize);

                // Пакуємо байти у велике число (Big-Endian формат)
                BigInteger m = new BigInteger(chunk, isUnsigned: true, isBigEndian: true);

                // ШИФРУВАННЯ: C = M^E mod N (використовуємо ключ клієнта)
                BigInteger c = BigInteger.ModPow(m, clientE, clientN);

                encryptedBlocks.Add(new EncryptedBlockDto
                {
                    Value = c.ToString(CultureInfo.InvariantCulture),
                    ByteLength = chunk.Length
                });
            }

            return encryptedBlocks;
        }
    }
}